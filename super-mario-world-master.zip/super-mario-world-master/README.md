# super-mario-world
Clean version of the Super Mario World ROM.
